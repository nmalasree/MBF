package com.cts.usermanagement.filter;

import com.cts.usermanagement.config.JwtTokenProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;

public class JwtAuthenticationFilter extends UsernamePasswordAuthenticationFilter implements JwtAuthFilter {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    public JwtAuthenticationFilter(AuthenticationManager authenticationManager, JwtTokenProvider jwtTokenProvider) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
        setFilterProcessesUrl("/api/v1.0/user/login");
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        try {
            // Extract credentials from the request
            User user = new ObjectMapper().readValue(request.getInputStream(), User.class);

            // Perform authentication
            return authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword(), Collections.emptyList())
            );
        } catch (IOException e) {
            throw new RuntimeException("Authentication failed", e);
        }
    }

    @Override
    public void successfulAuthentication(HttpServletRequest request, HttpServletResponse response,
                                         FilterChain chain, Authentication authResult) throws IOException {
        // Get the authenticated user
        User userDetails = (User) authResult.getPrincipal();

        // Generate JWT token
        String token = jwtTokenProvider.generateToken(userDetails.getUsername());

        // Add the token to the response header
        response.addHeader("Authorization", "Bearer " + token);
    }

    // Placeholder class for user credentials
    private static class UserCredentials {
        private String username;
        private String password;

        // Getters and setters
    }
}